# Random development notes

## GSettings

Use gsettings command to monitor or manipulate settings.
See https://askubuntu.com/questions/249887/gconf-dconf-gsettings-and-the-relationship-between-them

